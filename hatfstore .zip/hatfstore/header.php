<?php 
include 'db.php';

$sql = "SELECT * FROM options WHERE id = 1";
$result = mysqli_query($conn, $sql);
$options = mysqli_fetch_assoc($result);
?>

<!doctype html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width,  initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="assets/css/all.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animate.css">
    <link rel="stylesheet" href="assets/css/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/css/owl.theme.default.min.css">
    <link rel="icon" href="images">
    <title> <?php echo $options['logo'] ?></title>
    </head>
   <body>
     <header>  
   
        <div class="photo"><img src="assets/images/logo.jpeg" class="rounded w-100" style="height: 180px;"></div> 
      <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
  <a class="navbar-brand text-light" href="index.php"> <?php echo $options['logo'] ?></a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav ml-auto ">
      <li class="nav-item">
        <a class="nav-link text-light" href="content.php">شاهد المزيد</a>
      </li>
       <li class="nav-item">
        <a class="nav-link text-light" href="#">أخر الاصدارات</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-light" href="#">الديوان الصوتي</a>
      </li>
        <li class="nav-item">
        <a class="nav-link text-light" href="#">المستجلات الشعرية</a>
      </li>
        <li class="nav-item">
        <a class="nav-link text-light" href="#">شجرة ذوي مترك</a>
      </li>
        <li class="nav-item">
        <a class="nav-link text-light" href="#">المدونة</a>
      </li>
<li class="nav-item dropdown">
 <a class="nav-link dropdown-toggle text-light font-weight-bold" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">المنتجات</a>
    <div class="dropdown-menu">
      <?php
      $id = $_GET['id'];
      $sql = "SELECT * FROM category WHERE id = $id";
      $result = mysqli_query($conn, $sql);
       $category = mysqli_fetch_assoc($result);
        ?>
      <a class="dropdown-item" href="#elec"><?php echo $category['title']?> </a>
    </div>
      </li>
    </ul>
          </div>
</nav>  
                        
               <nav class="navbar navbar-light bg-light">
  <form class="form-inline" action="search.php">
      <div class="row">
    <input class="form-control mr-sm-2" type="text" placeholder="ابحث عن المنتجات والفئات" >
    <button class="btn btn-outline-success my-2 my-sm-0" type="submit"><i class="fas fa-search"></i></button>
  
             </div>
      </form>      
</nav> 
</header>