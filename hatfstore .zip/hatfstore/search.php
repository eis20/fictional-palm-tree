<?php 
include 'header.php'; 

$text = $_GET['q'];

?>
    <div class="container mt-5">
        <div class="row">
            
            <div class="col-md-9 main-content">

				<div class="row mb-5 dewan-row">
					
					<div class="col-12"><h2>Your result about: <?php echo $text; ?></h2></div>
					<?php 
					$sql = "SELECT * FROM dewan WHERE short_desc LIKE '%$text%' OR full_desc LIKE '%$text%'";
					$result = mysqli_query($conn, $sql);
					while ($dewan = mysqli_fetch_assoc($result)) {

					?>
					<div class="col-md-6 mb-4">
						<div class="card dewan-box">
					  <div class="card-body">
					    <h5 class="card-title"><?php echo $dewan['short_desc'] ?></h5>
					    <p class="card-text"><?php echo $dewan['full_desc'] ?></p>
					    <a href="signin.php?id=<?php echo $dewan['id'] ?>" class="btn btn-primary">Read More</a>
					  </div>
					</div>
					</div>
				<?php } ?>
				</div> 

            </div>
            
        </div>
    </div>
<?php include 'footer.php'; ?>