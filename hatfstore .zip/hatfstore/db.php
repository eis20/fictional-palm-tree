<?php
$conn = mysqli_connect("localhost", "root", "", "hatf-store");
?>