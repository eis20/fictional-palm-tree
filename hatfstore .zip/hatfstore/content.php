<?php include 'header.php';
$id = $_GET['id'];
$sql = "SELECT * FROM dewan WHERE id = $id";
$result = mysqli_query($conn, $sql);
$dewan = mysqli_fetch_assoc($result);

?>
        <div class="container">
        <div class="row">
            <main class="col-md">
            <h1><?php echo $dewan['short_desc']; ?><h2>
              <p> <?php echo $dewan['full_desc']; ?><P>
            </main>
            </div>
        </div>
        <hr>
       <?php include 'footer.php';?>