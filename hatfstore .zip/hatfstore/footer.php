<footer>
       <div class="container">
           <div class="row">
           <div class="col-6-md">
               <h4 class="badge badge-pill badge-danger" >نحن نقبل</h4>
               <br>
               <img src="assets/images/%D9%85%D8%AF%D9%89.png" class="rounded">
               <i class="fab fa-cc-mastercard fa-2x ml-5"></i>
               <i class="fab fa-cc-visa fa-2x ml-5"></i>
               <img src="assets/images/stcpay.png" class="rounded ml-5" >
               <i class="fab fa-apple-pay fa-3x ml-5"></i>
               </div>
                <div class="col-6-md">
               <h5 class="badge badge-pill badge-success ml-5" >تواصلو معنا</h5>
               <br>
                    <div class="row">
                        <div class="container">
              <a href="https://twitter.com/hajssa34?lang=en" class="col-4-md ml-5"><i class="fab fa-twitter fa-2x"></i>
                            
                            </a>
                            <a href="" class="col-4-md ml-5"><i class="fas fa-envelope text-secondary fa-2x"></i></a>
              <a href="" class="col-4-md ml-5"><i class="fab fa-whatsapp fa-2x text-success"></i></a>
                            </div>
              </div> </div>
              
             
                   
           </div>
           </div>
           <hr>
             <p class="text-center">nifo75@moi30.com</p>
               <p class="text-center">+966 59 239 1285</p>
           <hr>
           <p class="text-center font-weight-bold">حقوق الطبع محفوظة لموقع هتف القلوب</p>
       </footer>
        <script src="assets/js/jquery-3.4.1.min.js"></script>
        <script src="assets/js/popper.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/owl.carousel.min.js"></script>
        <script src="assets/js/wow.min.js"></script>
        <script src="assets/js/script.js"></script>
        <script>new WOW().init();</script>
      
    </body>
</html>