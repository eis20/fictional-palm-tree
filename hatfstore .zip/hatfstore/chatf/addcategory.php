<?php 
include 'header.php';
include 'sidebar.php';
$_SESSION['msg'] = '';
if(isset($_GET['add'])) {
  $title = htmlspecialchars($_GET['title']);
  $image       = $_FILES['image'];

   $img_name = $image['name'];
  $img_tmp = $image['tmp_name'];
  $ex = pathinfo($img_name, PATHINFO_EXTENSION);
  $img_name = 'hatf_store_project_'.time().'.'.$ex;
  move_uploaded_file($img_tmp, '../uploads/'.$img_name);


  $sql = "INSERT INTO category (title,image) VALUES ('$title','$img_name')";
  if(mysqli_query($conn, $sql)) {
    $_SESSION['msg'] = 'Category Added Successfuly';
    header("Location: allCategories.php");
  }
}



if(isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $sql = "SELECT * FROM category WHERE id = $id";
  $result = mysqli_query($conn, $sql);
  $cat = mysqli_fetch_assoc($result);
}

if(isset($_GET['edit_cat'])) {
  $title = htmlspecialchars($_GET['title']);
  $id = $_GET['cat_id'];
  $image       = $_FILES['image'];

  if(!empty($image['name'])) {
    $img_name = $image['name'];
    $img_tmp = $image['tmp_name'];
    $ex = pathinfo($img_name, PATHINFO_EXTENSION);
    $img_name = 'hatf_store_project_'.time().'.'.$ex;
    move_uploaded_file($img_tmp, '../uploads/'.$img_name);
  }else {
    $img_name = $_POST['ex_img'];
  }
  $sql = "UPDATE category SET title = '$title',image = '$img_name' WHERE id = $id";
  if(mysqli_query($conn, $sql)) {
    header("Location: allCategories.php");
  }
}
?>  
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa fa-bars"></i> <?php echo (isset($_GET['edit'])) ? 'Edit' : 'Add'; ?> Category</h3>
          </div>
        </div>
        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                <?php echo (isset($_GET['edit'])) ? 'Edit' : 'Add'; ?> Category
              </header>
              <div class="panel-body">
                <?php if(!empty($_SESSION['msg'])) { ?>
                <div class="alert alert-success fade in">
                  <button data-dismiss="alert" class="close close-sm" type="button">
                  x
                  </button>
                  <strong>Well done!</strong> <?php echo $_SESSION['msg']; ?>
                </div>
                <?php } ?>
                <form method="get" action="">
                  <?php if(isset($_GET['edit'])) { ?>
                  <input type="hidden" name="cat_id" value="<?php echo $id ?>">
                  <?php } ?>
                  <div class="form-group">
                    <input type="text" class="form-control" value="<?php echo (isset($cat['title'])) ? $cat['title'] : '' ?>" name="title" placeholder="Title">
                  </div>
                  <label>Image</label>
                    <input type="file" class="form-control" name="image">
                    <?php if(isset($_GET['edit'])) { ?>
                  <input type="hidden" name="ex_img" value="<?php echo $category['image'] ?>">
                  <img src="../uploads/<?php echo $category['image'] ?>" alt="">
                  <?php } ?>
                  </div>
                  <input class="btn btn-success" type="submit" name="<?php echo (isset($_GET['edit'])) ? 'edit_cat' : 'add'; ?>" value="<?php echo (isset($_GET['edit'])) ? 'Edit' : 'Add'; ?>">
                </form>
              </div>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
<?php include 'footer.php'; ?> 

<?php 