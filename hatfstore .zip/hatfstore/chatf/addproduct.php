<?php 
include 'header.php';
include 'sidebar.php';

if(isset($_POST['add'])) {
  $title       = htmlspecialchars($_POST['title']);
  $image       = $_FILES['image'];
  $category_id = $_POST['category_id'];

  $img_name = $image['name'];
  $img_tmp = $image['tmp_name'];
  $ex = pathinfo($img_name, PATHINFO_EXTENSION);
  $img_name = 'hatf_store_project_'.time().'.'.$ex;
  move_uploaded_file($img_tmp, '../uploads/'.$img_name);

  $title = str_replace("'", "\'", $title);

  $sql = "INSERT INTO products (title,  image, category_id) VALUES ('$title', '$img_name', $category_id)";
  if(mysqli_query($conn, $sql)) {
    header("Location: allproduct.php");
  }else {
    echo 'Error ' . mysqli_error($conn);
  }
}



if(isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $sql = "SELECT * FROM products WHERE id = $id";
  $result = mysqli_query($conn, $sql);
  $products = mysqli_fetch_assoc($result);
}


if(isset($_POST['edit_product'])) {
  $id = $_POST['product_id'];
  $title       = htmlspecialchars($_POST['title']);
  $image       = $_FILES['image'];
  $category_id = $_POST['category_id'];

  if(!empty($image['name'])) {
    $img_name = $image['name'];
    $img_tmp = $image['tmp_name'];
    $ex = pathinfo($img_name, PATHINFO_EXTENSION);
    $img_name = 'hatf_store_project_'.time().'.'.$ex;
    move_uploaded_file($img_tmp, '../uploads/'.$img_name);
  }else {
    $img_name = $_POST['old_img'];
  }

  $sql = "UPDATE products SET title = '$title', image = '$img_name', category_id = $category_id WHERE id = $id";
  mysqli_query($conn, $sql);
  header("Location: allproduct.php");

}



?>  
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa fa-bars"></i> Add product</h3>
          </div>
        </div>
        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Add Product
              </header>
              <div class="panel-body">
                <form method="post" action="" enctype="multipart/form-data">
                  <?php if(isset($_GET['edit'])) { ?>
                  <input type="hidden" name="product_id" value="<?php echo $id ?>">
                  <?php } ?>
                  <div class="form-group">
                    <input type="text" class="form-control" name="title" placeholder="Title" value="<?php echo $products['title'] ?>">
                  </div>
                  <div class="form-group">
                    <label>Image</label>
                    <input type="file" class="form-control" name="image">
                    <?php if(isset($_GET['edit'])) { ?>
                  <input type="hidden" name="old_img" value="<?php echo $products['image'] ?>">
                  <img src="../uploads/<?php echo $products['image'] ?>" alt="">
                  <?php } ?>
                  </div>
                  <div class="form-group">
                    <select class="form-control" name="category_id">
                      <?php 
                      $sql = "SELECT * FROM category";
                      $result = mysqli_query($conn, $sql);
                      while($cat = mysqli_fetch_assoc($result)) {
                      ?>

                      <option <?php echo ($cat['id'] == $products['category_id']) ? 'selected' : ''; ?> value="<?php echo $cat['id'] ?>"><?php echo $cat['title'] ?></option>

                      <?php } ?>
                    </select>
                  </div>
                  <input class="btn btn-success" type="submit" name="<?php echo (isset($_GET['edit'])) ? 'edit_product' : 'add'; ?>">
                </form>
              </div>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
<?php include 'footer.php'; ?> 



