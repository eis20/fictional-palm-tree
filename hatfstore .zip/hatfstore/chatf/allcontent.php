<?php 
include 'header.php';
include 'sidebar.php';

if(isset($_GET['del'])) {
  $id = $_GET['del'];
  $sql = "DELETE FROM dewan WHERE id = $id";
  mysqli_query($conn, $sql);
  header("Location: allcontent.php");
}

?>  
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa fa-bars"></i> All content</h3>
          </div>
        </div>
        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                All content
              </header>

              <table class="table table-striped table-advance table-hover">
                <tbody>
                  <tr>
                    <th> ID</th>
                    <th>short description</th>
                     <th> full description</th>
                    <th> Action</th>
                  </tr>
                  <?php 
                  $sql ="SELECT * FROM dewan";
                  $result = mysqli_query($conn, $sql);
                  while($dewan = mysqli_fetch_assoc($result)) {
                  ?>
                  <tr>
                    <td><?php echo $dewan['id']; ?></td>
                     <td><?php echo $dewan['short_desc'] ?></td>
                    <td><?php echo $dewan['full_desc'] ?></td>
                    <td>
                      <div class="btn-group">
                        <a class="btn btn-primary" href="addcontent.php?edit=<?php echo $dewan['id']; ?>"><i class="icon_pencil"></i></a>
                        <a onclick="return confirm('Are You Sure?')" class="btn btn-danger" href="allcontent.php?del=<?php echo $dewan['id']; ?>"><i class="icon_close_alt2"></i></a>
                      </div>
                    </td>
                  </tr>

                  <?php } ?>
                  
                </tbody>
              </table>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
<?php 


function get_cat_name($conn, $id) {
  $sql = "SELECT title FROM category WHERE id = $id";
  $result = mysqli_query($conn, $sql);
  $title = mysqli_fetch_assoc($result);
  $title = $title['title'];
  return $title;
}


include 'footer.php'; ?>    