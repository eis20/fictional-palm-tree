<?php 
include 'header.php';
include 'sidebar.php';


if(isset($_POST['add'])) {
 $short_desc  = htmlspecialchars($_GET['short_desc']);
  $full_desc   = $_POST['full_desc'];

$short_desc = str_replace("'", "\'", $short_desc);

  $sql = "INSERT INTO dewan (short_desc, full_desc) VALUES ( '$short_desc', '$full_desc')";
  if(mysqli_query($conn, $sql)) {
    header("Location: allcontent.php");
  }else {
    echo 'Error ' . mysqli_error($conn);
  }
}
if(isset($_GET['edit'])) {
  $id = $_GET['edit'];
  $sql = "SELECT * FROM dewan WHERE id = $id";
  $result = mysqli_query($conn, $sql);
  $dewan = mysqli_fetch_assoc($result);
}
if(isset($_POST['edit_dewan'])) {
  $id = $_POST['dewan_id'];
  $short_desc  = htmlspecialchars($_POST['short_desc']);
  $full_desc   = $_POST['full_desc'];

$sql = "UPDATE dewan SET  short_desc = '$short_desc', full_desc = '$full_desc' WHERE id = $id";
  mysqli_query($conn, $sql);
  header("Location: allcontent.php");
}
?>




<section id="main-content">
      <section class="wrapper">
<div class="panel-body">
                <form class="form-horizontal " method="get">
                  <div class="form-group">
                    <label class="col-sm-2 control-label">title</label>
                    <div class="col-sm-10">
                      <input type="text" class="form-control" name="short_desc" value="<?php echo $dewan['short_desc'] ?>">
                    </div>
                  </div>
 <div class="col-lg-12">
                <section class="panel">
                  <header class="panel-heading">
                    description
                  </header>
                  <div class="panel-body">
                    <div class="form" name="full_desc">
                      <form action="#" class="form-horizontal" method="get">
                        <div class="form-group">
                          <label class="control-label col-sm-2">description</label>
                          <div class="col-sm-10">
                            <textarea class="form-control ckeditor" name="editor1" rows="6" name="full_desc"> <?php echo $dewan['full_desc'] ?></textarea>
                          </div>
                        </div>
                      </form>
                    </div>
                  </div>
                </section>
              </div>
              <input class="btn btn-success" type="submit" name="<?php echo (isset($_GET['edit'])) ? 'edit_dewan' : 'add'; ?>" value="<?php echo (isset($_GET['edit'])) ? 'Edit' : 'Add'; ?>">
                </form>
</section></section>

<?php include 'footer.php';?>