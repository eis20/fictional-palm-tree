<?php 
include 'header.php';
include 'sidebar.php';

if(isset($_GET['del'])) {
  $id = $_GET['del'];
  $sql = "DELETE FROM products WHERE id = $id";
  mysqli_query($conn, $sql);
  header("Location: allproduct.php");
}

?>  
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa fa-bars"></i> All Products</h3>
          </div>
        </div>
        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                All Products
              </header>

              <table class="table table-striped table-advance table-hover">
                <tbody>
                  <tr>
                    <th> Title</th>
                    <th> Image</th>
                    <th> Category</th>
                    <th> Action</th>
                  </tr>
                  <?php 
                  $sql = "SELECT * FROM products";
                  $result = mysqli_query($conn, $sql);
                  while($products = mysqli_fetch_assoc($result)) {
                  ?>
                  <tr>
                    <td><?php echo $products['title'] ?></td>
                    <td><img width="50" src="../uploads/<?php echo $products['image'] ?>" alt=""></td>
                    <td><?php echo get_cat_name($conn, $products['category_id']) ?></td>
                    <td>
                      <div class="btn-group">
                        <a class="btn btn-primary" href="addproduct.php?edit=<?php echo $products['id'] ?>"><i class="icon_pencil"></i></a>
                        <a onclick="return confirm('Are You Sure')" class="btn btn-danger" href="allproduct.php?del=<?php echo $products['id'] ?>"><i class="icon_close_alt2"></i></a>
                      </div>
                    </td>
                  </tr>
                <?php } ?>
                  
                </tbody>
              </table>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
<?php 


function get_cat_name($conn, $id) {
  $sql = "SELECT title FROM category WHERE id = $id";
  $result = mysqli_query($conn, $sql);
  $title = mysqli_fetch_assoc($result);
  $title = $title['title'];
  return $title;
}


include 'footer.php'; ?>  


