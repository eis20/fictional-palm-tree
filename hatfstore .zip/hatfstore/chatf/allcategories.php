<?php 
include 'header.php';
include 'sidebar.php';

if(isset($_GET['del'])) {
  $id = $_GET['del'];
  $sql = "DELETE FROM category WHERE id = $id";
  mysqli_query($conn, $sql);
  header("Location: allCategories.php");
}

?>  
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa fa-bars"></i> All Categories</h3>
          </div>
        </div>
        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                All Categories
              </header>

              <table class="table table-striped table-advance table-hover">
                <tbody>
                  <tr>
                    <th> ID</th>
                    <th> Title</th>
                     <th> Image</th>
                    <th> Action</th>
                  </tr>
                  <?php 
                  $sql ="SELECT * FROM category";
                  $result = mysqli_query($conn, $sql);
                  while($cat = mysqli_fetch_assoc($result)) {
                  ?>
                  <tr>
                    <td><?php echo $cat['id']; ?></td>
                    <td><?php echo $cat['title']; ?></td>
                    <td><img width="50" src="../uploads/<?php echo $category['image'] ?>" alt=""></td>
                    <td>
                      <div class="btn-group">
                        <a class="btn btn-primary" href="addCategory.php?edit=<?php echo $cat['id']; ?>"><i class="icon_pencil"></i></a>
                        <a onclick="return confirm('Are You Sure?')" class="btn btn-danger" href="allCategories.php?del=<?php echo $cat['id']; ?>"><i class="icon_close_alt2"></i></a>
                      </div>
                    </td>
                  </tr>

                  <?php } ?>
                  
                </tbody>
              </table>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
<?php include 'footer.php'; ?>  