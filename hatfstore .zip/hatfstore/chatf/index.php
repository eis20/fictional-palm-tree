<?php 
include 'header.php';
include 'sidebar.php';

$sql = "SELECT * FROM options WHERE id = 1";
$result = mysqli_query($conn, $sql);
$options = mysqli_fetch_assoc($result);


if(isset($_POST['update'])) {
  $logo       = htmlspecialchars($_POST['logo']);
  $side_title = htmlspecialchars($_POST['side_title']);
  $copyright  = htmlspecialchars($_POST['copyright']);

  $sql = "UPDATE options SET logo = '$logo', side_title = '$side_title', copyright = '$copyright' WHERE id = 1";
  mysqli_query($conn, $sql);
  header("Location: index.php");
}


?>  
    <section id="main-content">
      <section class="wrapper">
        <div class="row">
          <div class="col-lg-12">
            <h3 class="page-header"><i class="fa fa fa-bars"></i> Options</h3>
          </div>
        </div>
        <!-- page start-->
        <div class="row">
          <div class="col-lg-12">
            <section class="panel">
              <header class="panel-heading">
                Options Page
              </header>
              <div class="panel-body">
                <form method="post" action="">
                  <div class="form-group">
                    <input type="text" class="form-control" value="<?php echo $options['logo'] ?>" name="logo" placeholder="Logo">
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" value="<?php echo $options['side_title'] ?>" name="side_title" placeholder="Sidebar Title">
                  </div>
                  <div class="form-group">
                    <input type="text" class="form-control" value="<?php echo $options['copyright'] ?>" name="copyright" placeholder="Copyright">
                  </div>
                  <input type="submit" name="update" class="btn btn-success" value="Update">
                </form>
              </div>
            </section>
          </div>
        </div>
        <!-- page end-->
      </section>
    </section>
<?php include 'footer.php'; ?>  