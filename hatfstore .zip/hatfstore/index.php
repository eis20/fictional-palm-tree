<?php include 'header.php'; 

    ?>
       <main>
           <div class="container">
           <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel" style="height: 180px;">
  <div class="carousel-inner" role="listbox">
    <div class="carousel-item active">
      <img class="d-block w-100" src="assets/images/logo.jpeg" alt="900x400" data-holder-rendered="true">
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="assets/images/logo.jpeg" data-src="holder.js/900x400?theme=industrial" alt="900x400" data-holder-rendered="true">
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>
               </div>
           <br><br><br>
           <div class="fourth">
           <div class="container">
               <div class="row">
                    <hr class="col-sm-9">
                   <h3 class="col-sm-3" style="margin-top: -35px;">الفئات</h3>
                   <div class="row">
             <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1469833120660-1a218b53d28a?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> ادوات خياطة</div>
</div>
</div>  
             <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1578916171728-46686eac8d58?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> البقالة </div>
</div>
</div>

                   
             <div class="col-3-md mt-sm-5 mycol">
<div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1588618319344-424aa94f749e?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> كتب </div>
</div>
                   </div>  
             <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1560769629-975ec94e6a86?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> احذية </div>
</div>

                   </div>  
                     <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1576574273295-fec3463e112f?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> منتجات تجميل </div>
</div>

                   </div> 
                     <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1524758631624-e2822e304c36?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> اثاث المنزل</div>
</div>

                   </div>  
                     <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1535683577427-740aaac4ec25?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
  <div class="card-body badge badge-pill badge-primary"> العطور </div>
</div>

                   </div>  
                     <div class="col-3-md mt-sm-5 mycol">
 <div class="card ml-lg-5">
  <img class="card-img-top" src="https://images.unsplash.com/photo-1593642633279-1796119d5482?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=500&q=60" alt="Card image cap" style="height: 100px;width: 300px;">
 <div class="card-body badge badge-pill badge-primary">  الالكترونيات </div>
</div>

                   </div> 
                       </div>
               </div>
               </div>
           </div><br><br>
           <div class="fifth">
               <div class="container">
               <h3>الاكثر مبيعاً</h3>
               <hr>
                     <?php   $id = $_GET['id'];
             $sql = "SELECT * FROM products WHERE category_id = 1";
             $result = mysqli_query($conn, $sql);
             $products = mysqli_fetch_assoc($result);
             
?>
           <div class="owl-carousel owl-theme">
    <div class="item"><h4 style="height: 170px;"><img src="uploads/<?php echo $products['image'] ?>"> <small class="text-center"><?php echo $products['title'] ?></h4></div>
  
</div></div>
           </div>
                   <br><br>
           <div class="sexth">
               <div class="container"><a name="cosm"></a>
               <h3>منتجات التجميل</h3>
               <hr>
                <?php   $id = $_GET['id'];
             $sql = "SELECT * FROM products WHERE category_id = 2";
             $result = mysqli_query($conn, $sql);
             $products = mysqli_fetch_assoc($result);
             
?>
           <div class="owl-carousel owl-theme">
    <div class="item"><h4><img src="uploads/<?php echo $products['image'] ?>" ><small class="text-center"><?php echo $products['title'] ?></small></h4></div>

</div></div>
           </div>
                   <br><br>
                   

           
           <div class="fifth">
               <div class="container"><a name="elec"></a>
               <h3>تالكترونيات/</h3>
               <hr>
 <?php   $id = $_GET['id'];
             $sql = "SELECT * FROM products WHERE category_id = 3";
             $result = mysqli_query($conn, $sql);
             $products = mysqli_fetch_assoc($result);
             
?>
           <div class="owl-carousel owl-theme">
     <div class="item"><img src="uploads/<?php echo $products['image'] ?>" ><small class="text-center"><?php echo $products['title'] ?></small></div>

  
</div>
</div>
           </div>
</main>
       <hr>

<?php include 'footer.php'; ?>